<TS language="bn" version="2.1">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Right-click to edit address or label</source>
        <translation>ঠিকানা কিংবা লেভেল সম্পাদনার জন্য রাইট-ক্লিক করুন</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation>নতুন একটি ঠিকানা তৈরি করুন</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation>নূতন</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>কপি/প্রতিলিপি</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>কপি/প্রতিলিপি</translation>
    </message>
    </context>
<context>
    <name>AddressTableModel</name>
    <message>
        <source>Address</source>
        <translation>ঠিকানা </translation>
    </message>
    </context>
<context>
    <name>AskPassphraseDialog</name>
    </context>
<context>
    <name>BanTableModel</name>
    </context>
<context>
    <name>BitcoinGUI</name>
    <message>
        <source>Warning</source>
        <translation>সতর্কতা</translation>
    </message>
    </context>
<context>
    <name>CoinControlDialog</name>
    </context>
<context>
    <name>EditAddressDialog</name>
    </context>
<context>
    <name>FreespaceChecker</name>
    </context>
<context>
    <name>HelpMessageDialog</name>
    </context>
<context>
    <name>Intro</name>
    </context>
<context>
    <name>ModalOverlay</name>
    </context>
<context>
    <name>OpenURIDialog</name>
    </context>
<context>
    <name>OptionsDialog</name>
    </context>
<context>
    <name>OverviewPage</name>
    </context>
<context>
    <name>PaymentServer</name>
    </context>
<context>
    <name>PeerTableModel</name>
    </context>
<context>
    <name>QObject</name>
    </context>
<context>
    <name>QObject::QObject</name>
    </context>
<context>
    <name>QRImageWidget</name>
    </context>
<context>
    <name>RPCConsole</name>
    </context>
<context>
    <name>ReceiveCoinsDialog</name>
    </context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <source>Address</source>
        <translation>ঠিকানা </translation>
    </message>
    </context>
<context>
    <name>RecentRequestsTableModel</name>
    </context>
<context>
    <name>SendCoinsDialog</name>
    </context>
<context>
    <name>SendCoinsEntry</name>
    </context>
<context>
    <name>SendConfirmationDialog</name>
    </context>
<context>
    <name>ShutdownWindow</name>
    </context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <source>The entered address is invalid.</source>
        <translation>প্রবেশকৃত ঠিকানাটি শুদ্ধ নয়।</translation>
    </message>
    <message>
        <source>Please check the signature and try again.</source>
        <translation>অনুগ্রহ করে স্বাক্ষরটি পুনরায় পরীক্ষা করে আবারও চেষ্টা করুন।</translation>
    </message>
    </context>
<context>
    <name>SplashScreen</name>
    </context>
<context>
    <name>TrafficGraphWidget</name>
    </context>
<context>
    <name>TransactionDesc</name>
    </context>
<context>
    <name>TransactionDescDialog</name>
    </context>
<context>
    <name>TransactionTableModel</name>
    </context>
<context>
    <name>TransactionView</name>
    <message>
        <source>Address</source>
        <translation>ঠিকানা </translation>
    </message>
    </context>
<context>
    <name>UnitDisplayStatusBarControl</name>
    </context>
<context>
    <name>WalletFrame</name>
    </context>
<context>
    <name>WalletModel</name>
    </context>
<context>
    <name>WalletView</name>
    </context>
<context>
    <name>bitcoin-core</name>
    <message>
        <source>Block creation options:</source>
        <translation>ব্লক তৈরির অপশনগুলো:</translation>
    </message>
    <message>
        <source>Debugging/Testing options:</source>
        <translation>ডিবাগিং/টেস্টিং অপশন:</translation>
    </message>
    <message>
        <source>Do you want to rebuild the block database now?</source>
        <translation>আপনি কি পুনরায় ব্লক ডাটাবেইজ এখনই তৈরি করতে চান?</translation>
    </message>
    <message>
        <source>RPC server options:</source>
        <translation>আরপিসি সার্ভার অপশন:</translation>
    </message>
    <message>
        <source>This is experimental software.</source>
        <translation>এটি পরীক্ষামূলক সফটওয়্যার।</translation>
    </message>
    <message>
        <source>Transaction amount too small</source>
        <translation>লেনদেনের পরিমান অনেক ছোট</translation>
    </message>
    <message>
        <source>Transaction too large</source>
        <translation>লেনদেনর অংক অনেক বড়</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>সতর্কতা</translation>
    </message>
    </context>
</TS>